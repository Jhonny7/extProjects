# Repo Backend Grup 4 de EA Q1 2024-25 --> TeachMe
Jordi Figueras, Pere Garcés, Bryan García i Júlia Roquet
